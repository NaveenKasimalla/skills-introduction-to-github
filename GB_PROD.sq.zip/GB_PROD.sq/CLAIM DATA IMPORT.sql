/*	 


alter table claim add AdjusterFax int;
drop table ##claim
drop table ##claimSampleReplica
drop table DBOps.dbo.Claim_GB
*/
--select * from AdjusterFax



select * from RSImport..RSIMPORTS_PACKAGE_INPUT where ClientId = 506

select * from RSImport..Claim where ClientId = 506
----- STEP 1  ----- INSERT FLIEBATCH ID INTO FILEBATCH TABLE FOR FURTHER INSERTS-----------
declare @fileName varchar (100)

set @fileName= 'Claim_GB' 

insert into  FileBatch (InputId, FileName, InProcess, ReceivedDate, CompleteDate, ClientId, BatchAckDirectoryFolder, IsBulkLoad)
		values 	('6',	@fileName, 0 ,	getdate(),	NULL	,'506',	NULL, 1 ) --FOR UAT
		--values 	('5',	@fileName,  0 ,	getdate(),	NULL	,'506',	NULL, 1 ) --FOR PROD

----- STEP 2  ----- CREATE TABLE FOR CLAIMS ---------------------------
CREATE TABLE DBOps.DBO.Claim_GB (
	[Data] [varchar](2697) ) -----MAIN FILE


SELECT * FROM DBOps.DBO.[Claim_GB] --521
--DROP TABLE DBOps.DBO.[AVIDEL mitchell-claims-20190201-172719]


 
--select distinct jurisdiction from ##claimSample
----- STEP 4  ----- CHECK IF THERE IS ANY INVALID DATA  ---------------------------
--select * from DBOps.DBO.[AVIDEL mitchell-claims-20190201-172719]  --
--select count(*) from DBOps.DBO.[AVIDEL mitchell-claims-20190201-172719]  -6402
--select * from ##CLAIMSAMPLE
--select COUNT(*) from ##CLAIMSAMPLE  --427681 
--select injury_date,*  from ##claimSample where  injury_date = '00000000' 
--select  birthdate from ##claimSample where  birthdate  = '00000000' 
--select injury_date,*  from ##claimSample where  injury_date is null
--select substring ( employer,0, CHARINDEX (',',employer,0) ) from ##claimSample where len(employer)>50
--select * from ##claim --select * from ##claimSample
--select adjuster_external_id,* from ##CLAIMSAMPLE where adjuster_external_id =''
--SELECT DISTINCT ADJUSTER_NICK,adjuster_external_id from ##CLAIMSAMPLE
--select * from ##CLAIMSAMPLE where second_ID not like '%LWC%' and  second_ID !='' --32
----- STEP 5  ----- UPDATE INVALID DATA TO REMOVE ANY FUTURE ERROR  ---------------------------

 -- update ##claimSample set injury_date = null where  injury_date = '00000000'
 --update ##claimSample set birthdate = null where  birthdate = '00000000'
 --update ##claimSample set employer = (substring ( employer,0, CHARINDEX (',',employer,0) )) where len(employer)>50
 ---- update ##claimSample set birthdate = null where  birthdate = ''

  
---========================================== =========================================================================
 -- drop table ##claimSampleReplica

 

declare @filebatchid int 
select @filebatchid= max(filebatchid) from FileBatch where ClientId = '506' AND FILENAME LIKE '%Claim_GB%'
--select @filebatchid

select 
'10902' as LocationId,		----LOCATION ID USED FOR REVIEWSTAT
'506' as ClientId,
														 
LTRIM(RTRIM(claim_id)) as ExternalClaimNumber,
----CASE WHEN second_ID like 'FP1%' THEN
----LEFT(RTRIM(second_ID),3)+ '-'+ Substring(RTRIM(second_ID), 4, 4) + '-' + CONVERT(varchar,CAST(SUBSTRING(RTRIM(second_ID), 8, LEN(RTRIM(second_ID))-7) AS INT)) 
----ELSE  LTRIM(RTRIM(second_id)) END AS ExternalClaimNumber,
	
LTRIM(RTRIM(claim_no)) as ClaimNumber,
isnull( convert(datetime, injury_date,105),getdate()) as DOI,

--case when (jurisdiction = '' or  jurisdiction is null ) then  '-999' 
	-- When Jurisdiction = 'LS' then 'LA' else jurisdiction end as JurisdictionId,

--LTRIM(RTRIM(jurisdiction_id1)) as JurisdictionClaimNumber,

Case  When LTRIM(RTRIM(Jurisdiction)) = 'CA' then '6' 
        When LTRIM(RTRIM(Jurisdiction)) = 'TX' then '47' end as JurisdictionId,

LTRIM(RTRIM(employer)) as Employer,
LTRIM(RTRIM(employer_addr1)) as EmployerAddress1,
--LTRIM(RTRIM(employer_addr2)) as EmployerAddress2,
LTRIM(RTRIM(employer_city)) as EmployerCity,
LTRIM(RTRIM(employer_state)) as EmployerStateId,
LTRIM(RTRIM(employer_zip)) as EmployerZip,
LTRIM(RTRIM(employer_phone)) as EmployerPhone,
LTRIM(RTRIM(employer_fax))  as EmployerFax,
LTRIM(RTRIM(employer_email)) as EmployerEmail,
--LTRIM(RTRIM(claim_status)) as ClaimStatusId,
LTRIM(RTRIM(adjuster_external_id)) as ExternalAdjusterId,
--null as ExternalAdjusterId,
----substring(adjuster_nick,CHARINDEX (',',adjuster_nick,0)+1,len(kl))  as AdjusterLName,
----substring (adjuster_nick,0,CHARINDEX(',',adjuster_nick,0)) as AdjusterFName,


LTRIM(RTRIM(adjuster_nick))as AdjusterFName,
LTRIM(RTRIM(adjuster_nick1)) as AdjusterLName,

--NULL as AdjusterLName,
--NULL as AdjusterFName,

----'Amtrust Group' as CarrierGroupId,			---NAME OFCURRENT DATA CLIENT
'65'  AS CarrierGroupId,
--LTRIM(RTRIM(body_part)) as InjuryDescription, ---null as InjuryDescription, --- suggested by dennis on 25 may 18
'0' as ProcessStatus,
--LTRIM(RTRIM(second_id)) as  ExternalCLAIMId,

null as EmployerCountryId,
Ad_fax as Fax,
email as AdjusterEmail,
null as DisputeId,
null as NetworkId,
null as NetworkEffectiveDate,
null as AdjusterMName,
null as AdjusterSuffix,
Ad_phone as AdjusterPhone,
null as AdjusterExtension,
null as AdjusterCellPhone,
null as AdjusterAddress1,
null as AdjusterAddress2,
null as AdjusterCity,
null as AdjusterStateId,
null as AdjusterZip,
null as AdjusterCountryId,
null as AdjusterClaimOffice,
null as AdjusterTCode,
fname as AttorneyFName,
null as AttorneyMName,
lname as AttorneyLName,
null as AttorneyPrefix,
null as AttorneySuffix,
null as AttorneyEmail,
null as AttorneyFirmName,
null as AttorneyAddress1,
null as AttorneyAddress2,
null as AttorneyCity,
null as AttorneyStateId,
null as AttorneyZip,
a_phone as AttorneyPhone,
null as AttorneyExtension,
a_fax as AttorneyFax,
null as AttorneyCountryId,
Atrny_Id as ExternalAttorneyId,
null as ClaimOffice,
null as ClaimOfficeAddress,
null as ClaimOfficeCity,
null as ClaimOfficeStateId,
null as ClaimOfficeZip,
null as ClaimOfficeCountryId,
null as ClaimOfficePhone,
null as ClaimOfficeFax,
null as CarrierId, ---'AmTrust' as CarrierId, -- Amba updated we can use null with carrier id 
--BodyPartID as BodyPartId,--body_part as BodyPartId, --- suggested by dennis on 25 may 18
CASE When BodyPartId = 'Abdomen (including groin)' then '79' 
    When BodyPartId = 'Ankle' then '88'
    When BodyPartId = 'Elbow' then '40' 
     When BodyPartId = 'Finger(s)' then '44' 	 
	 When BodyPartId = 'Foot' then '90' 
     When BodyPartId = 'Hand' then '43'
     When BodyPartId = 'Hip' then '83' 
     When BodyPartId = 'Knee' then '85' 	
	 When BodyPartId = 'Low Back Area (Lumbar and Lumbo-Sacral)' then '70' 
     When BodyPartId = 'Lower Arm' then '41'
     When BodyPartId = 'Lower Leg' then '87' 
     When BodyPartId = 'multiple body parts' then '106' 	 
	 When BodyPartId = 'Multiple Lower Extremities' then '38' 
     When BodyPartId = 'Pelvis' then '74'
     When BodyPartId = 'Shoulder(s)' then '65' 
     When BodyPartId = 'Soft Tissue - Neck' then '29' 	 
	 When BodyPartId = 'Upper Back Area (Thoracic Area)' then '69' 
     When BodyPartId = 'Wrist' then '42' end as BodyPartId,
	 --When BodyPartId = 'Soft Tissue - Head' then  'Soft Tissue - Head'
	-- When BodyPartId = 'Multiple Upper Extremities' then 'Multiple Upper Extremities' 
	 --When BodyPartId  = 'Thumb' then 'Thumb' end as BodyPartId,
null as CauseId,
null as NatureId,
null as BenefitWage,
null as BenefitPercent,
null as IndemnityReserve,
null as MedicalReserve,
null as TotalReserve,
null as IndemnityTotal,
null as BeginDate,
null as MedicalTotal,
null as MedicalDateBegan,
null as Total,
null as FullMedicalReleaseDate,
null as ReleaseDoctor,
null as ImpairmentPercentage,
null as ImpairmentDoctor,
null as ImpairmentGuideline,
null as WorkStatusId,
null as TPAName,
null as TPAAddress1,
null as TPAAddress2,
null as TPACity,
null as TPAStateId,
null as TPAZip,
null as TPACountryId,
null as TPAPhone,
null as TPAFax,
null as TPAEmail,
null as ClaimId,
null as Seq,
getdate () as CreateDateCst,
null as ClaimRiskId,
null as AdjusterTeam,
@filebatchid as FileBatchId,
null as ErrorMessage,
null as Side,
null as CSInjuryEmployerName,
null as CSInjuryEmployerAddress1,
null as CSInjuryEmployerAddress2,
null as CSInjuryEmployerCity,
null as CSInjuryEmployerStateId,
null as CSInjuryEmployerZip,
null as ClaimOfficeAddress2 ,
ExternalEmployeeId as ExternalEmployeeId,
----changed on 02112019
--CASE WHEN second_ID like 'LWC%' THEN
--LEFT(RTRIM(second_ID),3)+ '-'+ Substring(RTRIM(second_ID), 4, 4) + '-' + CONVERT(varchar,CAST(SUBSTRING(RTRIM(second_ID), 8, LEN(RTRIM(second_ID))-7) AS INT)) 
--	ELSE  LTRIM(RTRIM(second_id)) END AS SmartAdvisorClaimMicId ,

--LTRIM(RTRIM(second_ID)) AS SmartAdvisorClaimMicId ,

----null AS SmartAdvisorClaimMicId,
null as SmartAdvisorAdjusterMicId,
null as SmartAdvisorAttorneyMicId

into    ##claimSampleReplica
from DBOps.DBO.Claim_GB;
--where LTRIM(RTRIM(second_id )) like 'LWC%'


------------------------------------------------------------------------------------------------------------
--drop table DBOps.DBO.Claim_GB;

select * from DBOps.DBO.Claim_GB;
-- drop table ##claimSampleReplica
-- select * from ##claimSampleReplica
--select distinct JurisdictionId from ##claimSampleReplica'
-- select * from ##claimSampleReplica where externalclaimnumber= '00000000000007324699'
select distinct year(DOI), count(*)  from ##claimSampleReplica group by YEAR(DOI) order by 1
select count(*)  from ##claimSampleReplica where year(DOI) <2013 --112136

-------------------------------------------------------------------------------------------------------------


----- STEP 6  -----INSERT DATA INTO MAIN CLAIM TABLE   ---------------------------

select * from ##claimSampleReplica

insert into Rsimport.dbo.claim (LocationId,	ClientId,	ExternalClaimNumber,	ClaimNumber,	DOI,	JurisdictionId,	JurisdictionClaimNumber,	CoverageId,	ClaimOffice,	ClaimOfficeAddress,	ClaimOfficeCity,
 	ClaimOfficeStateId,	ClaimOfficeZip,	ClaimOfficeCountryId,	ClaimOfficePhone,	ClaimOfficeFax,	Employer,	EmployerAddress1,	EmployerAddress2,	EmployerCity,	EmployerStateId,	EmployerZip,	
	EmployerCountryId,	EmployerPhone,	EmployerFax,	EmployerEmail,	DisputeId,	ClaimStatusId,	NetworkId,	NetworkEffectiveDate,	ExternalAdjusterId,	Fax,	AdjusterEmail,	AdjusterLName,	AdjusterFName,	
	AdjusterMName,	AdjusterSuffix,	AdjusterPhone,	AdjusterExtension,	AdjusterCellPhone,	AdjusterAddress1,	AdjusterAddress2,	AdjusterCity,	AdjusterStateId,	AdjusterZip,
	AdjusterCountryId,	AdjusterClaimOffice,	AdjusterTCode,	AttorneyFName,	AttorneyMName,	AttorneyLName,	AttorneyPrefix,	AttorneySuffix,	AttorneyEmail,	AttorneyFirmName,
	AttorneyAddress1,	AttorneyAddress2,	AttorneyCity,	AttorneyStateId,	AttorneyZip,	AttorneyPhone,	AttorneyExtension,	AttorneyFax,	AttorneyCountryId,	ExternalAttorneyId,	CarrierId,	
	CarrierGroupId,	InjuryDescription,	BodyPartId,	CauseId,	NatureId,	BenefitWage,	BenefitPercent,	IndemnityReserve,	MedicalReserve,	TotalReserve,	IndemnityTotal,	
	BeginDate,	MedicalTotal,	MedicalDateBegan,	Total,	FullMedicalReleaseDate,	ReleaseDoctor,	ImpairmentPercentage,	ImpairmentDoctor,	ImpairmentGuideline,	
	WorkStatusId,	TPAName,	TPAAddress1,	TPAAddress2,	TPACity,	TPAStateId,	TPAZip,	TPACountryId,	TPAPhone,	TPAFax,	TPAEmail,	ProcessStatus,	ExternalEmployeeId,
	--ExternalCLAIMId,	
	/*ClaimId,	Seq,	CreateDateCst,	*/  ClaimRiskId, AdjusterTeam,	FileBatchId,	ErrorMessage,	Side,	CSInjuryEmployerName,	CSInjuryEmployerAddress1,
	CSInjuryEmployerAddress2,	CSInjuryEmployerCity,	CSInjuryEmployerStateId,	CSInjuryEmployerZip,	ClaimOfficeAddress2 ,
	SmartAdvisorClaimMicId, SmartAdvisorAdjusterMicId, SmartAdvisorAttorneyMicId)

select distinct 
  c.LocationId, '506' as ClientId,  c.ExternalClaimNumber,  ClaimNumber,  DOI, JurisdictionId, null as  JurisdictionClaimNumber,null as  CoverageId,null as ClaimOffice,null as ClaimOfficeAddress,
null as ClaimOfficeCity,	null as ClaimOfficeStateId,	null AS ClaimOfficeZip,	null as ClaimOfficeCountryId,	null as ClaimOfficePhone,	null as ClaimOfficeFax,	
LEFT(Employer,50), ---Employer, 	
EmployerAddress1,
null as EmployerAddress2,	 EmployerCity,	 EmployerStateId,	 EmployerZip,	null as EmployerCountryId,	 EmployerPhone, EmployerFax,	 EmployerEmail,	null as DisputeId,
null as ClaimStatusId,	null as NetworkId,	null as NetworkEffectiveDate,  ExternalAdjusterId,	---'186186' as ExternalAdjusterId, --'186186' ExternalAdjusterId,
null as Fax, AdjusterEmail,	 AdjusterLName,	 AdjusterFName,	null as AdjusterMName,	null as AdjusterSuffix,	
AdjusterPhone,	null as AdjusterExtension,	null as AdjusterCellPhone,	null as AdjusterAddress1,	null as AdjusterAddress2,	null as AdjusterCity,	null as AdjusterStateId,	null as AdjusterZip,	
null as AdjusterCountryId,	null as AdjusterClaimOffice,	null as AdjusterTCode, AttorneyFName,	null as AttorneyMName,	AttorneyLName,	null as AttorneyPrefix,	null as AttorneySuffix,	null as AttorneyEmail,	
null as AttorneyFirmName,	null as AttorneyAddress1,	null as AttorneyAddress2,	null as AttorneyCity,	null as AttorneyStateId,	null as AttorneyZip,AttorneyPhone,	null as AttorneyExtension, AttorneyFax,	
			null as AttorneyCountryId, ExternalAttorneyId,			NULL as CarrierId ,-- CarrierId,	
 CarrierGroupId,	null as InjuryDescription, BodyPartId,	null as CauseId,	null as NatureId,	null as BenefitWage,	null as BenefitPercent,
	null as IndemnityReserve,	null as MedicalReserve,	null as TotalReserve,	null as IndemnityTotal,	null as BeginDate,	null as MedicalTotal,	null as MedicalDateBegan,	null as Total,	null as FullMedicalReleaseDate,
	null as ReleaseDoctor,	null as ImpairmentPercentage,	null as ImpairmentDoctor,	null as ImpairmentGuideline,	null as WorkStatusId,	null as TPAName,	null as TPAAddress1,	null as TPAAddress2,	null as TPACity,
	null as TPAStateId,	null as TPAZip,	null as TPACountryId,	null as TPAPhone,	null as TPAFax,	null as TPAEmail,	'0' as ProcessStatus ,	ExternalEmployeeId,--null as ExternalCLAIMId,	
	/*  ClaimId,	Seq, 	CreateDateCst, */	 null as ClaimRiskId,
	null as AdjusterTeam,	FileBatchId,
	null as ErrrorMessage, null as 	Side,	 null as CSInjuryEmployerName,	 null as CSInjuryEmployerAddress1,	 null as CSInjuryEmployerAddress2,	
null as CSInjuryEmployerCity,	 null as CSInjuryEmployerStateId,	 null as CSInjuryEmployerZip,	 null as ClaimOfficeAddress2 ,
null as SmartAdvisorClaimMicId, null as SmartAdvisorAdjusterMicId, null as SmartAdvisorAttorneyMicId 
	from ##claimSampleReplica c 
inner join reviewstat.dbo.patient p on p.ExternalPatientId = c.ExternalEmployeeId 
--where c.claimnumber='153712'

--where C.ExternalCLAIMId  in (select ExternalPatientId from CLAIMlog (nolock) where filebatchid =10941) --2881
--not in 3519
--where c.ExternalClaimNumber <>'' --and  c.ExternalClaimNumber like 'FP%' 

------and year(c.DOI) <2013 --in (2013,2014,2015,2016) --148402 --in (2019,2018,2017)
select max(len(Employer)) from ##claimSampleReplica

select Employer,len(Employer),LEFT(Employer,50) from ##claimSampleReplica where len(Employer) >50
select * from claim;


select * from patient where PatientID=294952;

select * from patient where Fname = 'Ehab' and lname = 'Higgy';

select * from claim
