declare @fileName varchar (100)



set @fileName = 'Employee_GB' 

insert into  FileBatch (InputId, FileName, InProcess, ReceivedDate, CompleteDate, ClientId, BatchAckDirectoryFolder, IsBulkLoad)
				values 	('6',	@fileName, 0 ,	getdate(),	NULL	,'506',	NULL, 1)  --FOR UAT
				--values 	('5',	@fileName,  0 ,	getdate(),	NULL	,'506',	NULL, 1 ) --FOR PROD

				--select * from DBOps.DBO.[tmc-claims-20220225-170135]

----- STEP 3  ----- COLUMN WISE DATA MODIFICATION  ---------------------------

select max(filebatchid) from FileBatch  where ClientId = '506' and filename like '%Employee_GB%';
select * from FileBatch  where ClientId = '506' and filename like '%Employee_GB%';

--create table DBOps.dbo.Employee_GB;

 --Drop table DBOps.dbo.Employee_GB;

 --SELECT * FROM DBOps.dbo.Employee_GB
------------------------------------------------------------------------------------------------------------------------------------------------------

declare @filebatchid int 
select @filebatchid= max(filebatchid) from FileBatch  where ClientId = '506' and filename like '%Employee_GB%'
--select @filebatchid

select 
--LTRIM(RTRIM(claim_id)) as claim_id,
LTRIM(RTRIM(last_name)) as EmployeeLName,
LTRIM(RTRIM(first_name)) as EmployeeFName,
'' as EmployeeMName,
'' as EmployeePrefix,
'' as EmployeeSuffix,
LTRIM(RTRIM(ssn)) as EmployeeSSN,
LTRIM(RTRIM(second_id )) as  ExternalPatientId,
birthdate as EmployeeDOB,
LTRIM(RTRIM(sex)) as EmployeeGender,
LTRIM(RTRIM(strt_addr1 ))as EmployeeAddress1,
LTRIM(RTRIM(strt_addr2)) as EmployeeAddress2,
'' as EmployeeAdditionalAddress1,
'' as EmployeeAdditionalAddress2,
'' as EmployeeAdditionalAddress3,
LTRIM(RTRIM(city)) as EmployeeCity,
LTRIM(RTRIM(state)) as EmployeeState,

--Case  When LTRIM(RTRIM(state)) = 'CA' then '6' 
--When LTRIM(RTRIM(state)) = 'TX' then '47' end as EmployeeState,

LTRIM(RTRIM(zip)) as EmployeeZip,
'' as  EmployeeCountry,
LTRIM(RTRIM(phone)) as EmployeePhone,
'' as EmployeeCell,
--LTRIM(RTRIM(fax)) as EmployeeFax,
--LTRIM(RTRIM(email)) as EmployeeEmail,
'0' as ProcessStatus,
'' as EmployeeId,
getdate() as CreateDateCst,
'' as Seq,
'506' as ClientId,
@filebatchid as FileBatchId,
'' as ErrorMessage
into  ##ClaimEmployee
from DBOps.dbo.Employee_GB

--where LTRIM(RTRIM(second_id )) like 'LWC%'
select * from ##ClaimEmployee
 --select * from ##ClaimEmployee where employeedob like '%1900%'
 --select * from ##ClaimEmployee where employeedob = ''
-- drop table ##ClaimEmployee -- drop table ##ClaimSample
--select * from ##ClaimEmployee WHERE employeedob IS NULL

 /*
 update ##ClaimEmployee set EmployeeDOB = null where  EmployeeDOB = '00000000'
 update ##ClaimEmployee set EmployeeDOB = null where  year(convert(datetime,EmployeeDOB)) = '1900'

 */

 insert into RSIMPORT.DBO.Employee (EmployeeLName,EmployeeFName,EmployeeMName,EmployeePrefix,EmployeeSuffix,EmployeeSSN,ExternalPatientId,EmployeeDOB,EmployeeGender,EmployeeAddress1,
EmployeeAddress2,EmployeeAdditionalAddress1,EmployeeAdditionalAddress2,EmployeeAdditionalAddress3,EmployeeCity,EmployeeState,EmployeeZip,EmployeeCountry,EmployeePhone,
EmployeeCell,EmployeeFax,EmployeeEmail,ProcessStatus,/*EmployeeId,CreateDateCst,Seq,*/ClientId,FileBatchId,ErrorMessage)

select 
EmployeeLName ,  EmployeeFName ,EmployeeMName,EmployeePrefix,EmployeeSuffix, EmployeeSSN,
--case when EmployeeSSN is null or EmployeeSSN ='' or len(LTRIM(RTRIM(EmployeeSSN)))<10   then '888888888' else EmployeeSSN end as EmployeeSSN ,
ExternalPatientId, convert(datetime,EmployeeDOB) , ---convert(datetime,'1900-01-02'), 
EmployeeGender,
--case when EmployeeGender = '' or EmployeeGender is null or EmployeeGender ='U' then  '-999' else  EmployeeGender end as EmployeeGender
EmployeeAddress1,EmployeeAddress2,EmployeeAdditionalAddress1,EmployeeAdditionalAddress2,EmployeeAdditionalAddress3,EmployeeCity,EmployeeState,EmployeeZip,EmployeeCountry,EmployeePhone,
EmployeeCell,null as EmployeeFax,null as EmployeeEmail, '0' as ProcessStatus,/*EmployeeId,CreateDateCst,Seq,*/ ClientId, FileBatchId, ErrorMessage  
from  ##ClaimEmployee
where EmployeeDOB is not null  and  EmployeeLName <> '' and  EmployeeFName <> ''   --509 --121

----where EmployeeDOB is null  and  EmployeeLName <> '' and  EmployeeFName <> ''  
----1379 as  FileBatchId, '' as ErrorMessage from dbops.dbo.Ahshay_RS_Employee

--------and ExternalPatientId not in (select ExternalPatientId from ReviewStat..Patient (nolock))
----and ExternalPatientId in (
----select  distinct ExternalPatientID from dbops.dbo.Ahshay_RS_Employee where ExternalPatientID like 'fp%'and EmployeeDOB !='1900-01-01' and 
----ExternalPatientID not in (select ExternalPatientID from reviewstat.dbo.Patient 
----where clientid = 186 and locationid = 1000000193 and ExternalPatientID is not null and ExternalPatientID like 'FP%')

37549

select * from Employeewhere EmployeeFName = 'Ehab'

